//
//  ZipCreator.h
//  ZipCreator
//
//  Created by Cucumber Sandwich on 29/06/20.
//  Copyright © 2020 Ziplyne Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ZipCreator.
FOUNDATION_EXPORT double ZipCreatorVersionNumber;

//! Project version string for ZipCreator.
FOUNDATION_EXPORT const unsigned char ZipCreatorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZipCreator/PublicHeader.h>


